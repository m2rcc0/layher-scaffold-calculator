# Layher Scaffold Calculator

This is a starter React + TypeScript web application for calculating Layher scaffolding requirements.

## Running Locally

```bash
npm install
npm start
```

## StackBlitz

You can open this project in StackBlitz for instant online editing and preview.

## Features

- Simple calculator interface
- TypeScript for type safety
- Ready for customization